#!/bin/bash

zone=("" "all" "ws_ext_16" "ws_ext_17" "ws_ext_18")

read -p "What do you wnat to do (1:update, 2:install, 3:remove) : " todo
read -p """In which zone do you want to make the changes?
1: all
2: ws-ext-16
3: ws-ext-17
4: ws-ext-18
Please select zone: """ zn

if [[ $todo -eq 1 ]]
then
read -p "What do you wnat to upgrade: (* = will you upgrade all packages or write the exact name of the package):" update
ansible-playbook -e "pchosts=${zone[$zn]} pkgname=$update" -i inventory playbook.yml --tags "Update"
fi
if [[ $todo -eq 2 ]]
then
read -p "What do you want to install: " install
ansible-playbook -e "pchosts=${zone[$zn]} pkgname=$install" -i inventory playbook.yml --tags "Install"
fi
if [[ $todo -eq 3 ]]
then
read -p "What do you want to remove: " remove
ansible-playbook -e "pchosts=${zone[$zn]} pkgname=$remove" -i inventory playbook.yml --tags "Remove"
fi
