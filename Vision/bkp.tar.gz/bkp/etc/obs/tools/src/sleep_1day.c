#include <unistd.h>

int main() 
{
   sleep(86400);
   return 0;
}
