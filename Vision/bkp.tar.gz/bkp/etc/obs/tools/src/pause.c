#include <unistd.h>

int main() 
{
   pause();
   return 0;
}
